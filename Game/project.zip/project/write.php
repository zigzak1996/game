<?php
    $name=$_GET['name'];
    $win=$_GET['win'];
    $btn2=$_GET['btn2'];
    $btn1=$_GET['btn1'];
    $file=fopen("player.txt","r+")or die("dad");
    $all=fread($file, filesize("player.txt"));
    $all=$all+" "+$name+" "+$win;
    echo $all;
    fwrite($file,$all);
    fclose($file);

  ?>
